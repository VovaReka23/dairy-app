const initialState = {
	loadedСomments: false,
	comments: [
		{
			id: 1,
			idItem: 1,
			text: "A variation of the ordinary lorem ipsum text has been used in typesetting since the 1960s or earlier, when it was popularized by advertisements for Letraset transfer sheets. It wasintroduced to the Information Age in the mid-1980s"
		},
		{
			id: 2,
			idItem: 2,
			text: "A variation of the ordinary lorem ipsum text has been used in typesetting since the 1960s or earlier, when it was popularized by advertisements for Letraset transfer sheets."
		}
	],
	commentsItem: [],
	commentsCount: []
}

const comments = (state = initialState, action) => {
	switch (action.type) {
		case 'ADD_COMMENT':
			let newСomments = {
				id: Date.now(),
				idItem: action.payload.idUser,
				user: '#000',
				text: action.payload.text,
			};
			const comments = [...state.comments, newСomments];
			return {
				...state,
				comments: comments,
			};
		case 'SET_COMMENT_ITEM':
			const filterComments = state.comments.filter((comment) => comment.idItem === action.payload);
			return {
				...state,
				commentsItem: filterComments
			};
		// case 'SET_COMMENT_COUNT':
		// 	const filterComments = state.comments.filter((comment) => comment.idItem === action.payload);
		// 	return {
		// 		...state,
		// 		commentsItem: filterComments
		// 	};
		default:
			return state
	}
};

export default comments;
