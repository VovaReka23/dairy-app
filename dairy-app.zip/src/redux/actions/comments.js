
const addComment = (text, idUser) => ({
  type: 'ADD_COMMENT',
  payload: { text, idUser },
});
const setCommentsItem = (id) => ({
  type: 'SET_COMMENT_ITEM',
  payload: id,
});

export {
  addComment,
  setCommentsItem
}

